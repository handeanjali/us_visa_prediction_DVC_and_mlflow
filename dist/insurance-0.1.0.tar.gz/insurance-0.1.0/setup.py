from setuptools import setup, find_packages

setup(
    name="us_visa",
    version="0.0.0",
    author="Anjali",
    author_email="anjalihande16@gmail.com",
    packages=find_packages()
)